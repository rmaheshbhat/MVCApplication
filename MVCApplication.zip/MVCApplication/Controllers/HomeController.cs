﻿using MVCApplication.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace MVCApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult FileUpload()
        {
            return View();
        }

        [HttpPost]
        public ActionResult FileUpload(HttpPostedFileBase files)
        {

            String FileExt = System.IO.Path.GetExtension(files.FileName).ToUpper();
            string filePath = System.IO.Path.GetFullPath(files.FileName);           

            if (FileExt == ".PDF")
            {
                Stream str = files.InputStream;
                BinaryReader Br = new BinaryReader(str);
                Byte[] FileDet = Br.ReadBytes((Int32)str.Length);
                
                FileDetailsModel Fd = new Models.FileDetailsModel();
                Fd.FileName = files.FileName;
                Fd.FileContent = FileDet;
                Fd.FilePath = filePath;
                PdfDetails pdfDetails = GetTextFromPDF(Fd);
                // SaveFileDetails(Fd);
                //ViewBag.FileStatus = "File uploaded Successfully";
                //return RedirectToAction("FileUpload");
                List<PdfDetails> DetList = new List<PdfDetails>();
                DetList.Add(pdfDetails);
                return PartialView("FileDetails", DetList);
            }
            else
            {
                ViewBag.FileStatus = "Invalid file format.";
                return View();

            }

        }

        //private List<FileDetailsModel> GetFileList()
        //{
        //    List<FileDetailsModel> DetList = new List<FileDetailsModel>();

        //   //code to 
        //    return DetList;
        //}

        [HttpPost]
        public PartialViewResult Validate()
        {
           
                List<PdfDetails> DetList = TempData["pdfdetails"] as List<PdfDetails>;
            

            return PartialView("FileDetails", DetList);
        }
        private void SaveFileDetails(FileDetailsModel objDet)
        {
            //string value = System.Text.Encoding.UTF8.GetString(objDet.FileContent);
            //string encoded = HttpUtility.UrlEncode(Convert.ToBase64String(objDet.FileContent));
            ////var byteArray = System.Text.Encoding.UTF8.GetBytes(Request.QueryString["BytArray"]);
            //byte[] byteArray = Convert.FromBase64String(Server.UrlEncode(Convert.ToBase64String(objDet.FileContent)));
            //string x = System.Text.Encoding.UTF8.GetString(byteArray);

            //String content=GetTextFromPDF(objDet);
            //string testString = "Hello World !!";
            ////Here converting the string to byteArray
            //byte[] byteArray = Encoding.UTF8.GetBytes(testString);
            ////converting the byteArray to string
            //string str = Encoding.UTF8.GetString(objDet.FileContent, 0, objDet.FileContent.Length);
            //string test3 = ByteArrayToString(objDet.FileContent);
            //string bitString = BitConverter.ToString(objDet.FileContent);
            //string asciiString = Encoding.ASCII.GetString(objDet.FileContent, 0, objDet.FileContent.Length);
            //string text = Encoding.Unicode.GetString(objDet.FileContent);
            //string text1=Encoding.Default.GetString(objDet.FileContent);
            //string utfString = Encoding.UTF8.GetString(objDet.FileContent, 0, objDet.FileContent.Length);
        }
        //public static string ByteArrayToString(byte[] ba)
        //{
        //    StringBuilder stringHex = new StringBuilder(ba.Length * 2);
        //    foreach (byte b in ba)
        //    {
        //        stringHex.AppendFormat("{0:x2}", b);
        //    }
        //    return stringHex.ToString();
        //}
        private PdfDetails GetTextFromPDF(FileDetailsModel objDet)
        {
            StringBuilder text = new StringBuilder();
            PdfDetails pdfdetails = new PdfDetails();

            using (PdfReader reader = new PdfReader("C:\\Users\\Mahesh.bhat\\Desktop\\104N072V02.pdf"))
            {
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                }
                string content = text.ToString();
                pdfdetails.policyNo = content.Substring(content.IndexOf("Policy no.:") + "Policy no.:".Length, content.IndexOf("Telephone:") -(content.IndexOf("Policy no.:") + "Policy no.:".Length)).Trim();
                string telephone = content.Substring(content.IndexOf("Telephone:") + "Telephone:".Length, (content.IndexOf("Email id:")) - (content.IndexOf("Telephone:") + "Telephone:".Length)).Trim();
                pdfdetails.telephone = content.Substring(content.IndexOf("Telephone:") + "Telephone:".Length+1, 11).Trim();
                //string telephone = content.Substring(content.IndexOf("Telephone:") + "Telephone:".Length, content.IndexOf("Email id:") - (content.IndexOf("Telephone:") + "Telephone:".Length-1 + "Policy no.:".Length-1 +(policy.Length-1))).Trim();
                //string email = content.Substring(content.IndexOf("Email id:") + "Email id:".Length, content.IndexOf("Welcome") - (content.IndexOf("Email id:") + "Email id:".Length + "Telephone:".Length -1 + "Policy no.:".Length + (policy.Length - 1 + telephone.Length-1))).Trim();
                int lengthDiff = content.IndexOf("Telephone:") + "Telephone:".Length + 1 + telephone.Length;
                //pdfdetails.email = content.Substring((content.IndexOf("Telephone:") + "Telephone:".Length +1 + telephone.Length),((content.IndexOf("Email id:") + "Email id:".Length) - (lengthDiff))).Trim(); //PDf is not in format here so did a hardcode
                pdfdetails.email = "test@gmail.com";
            }
            return pdfdetails;


        }
    }
}