﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCApplication.Models
{
    public class ValidateInfo
    {
        public int PolicyNumber { get; set; }
        public int TelephoneNumber { get; set; }
        public string EmailId { get; set; }
    }

    public class FileDetailsModel
    {
        public int Id { get; set; }
        [Display(Name = "Uploaded File")]
        public String FileName { get; set; }
        public byte[] FileContent { get; set; }
        public string FilePath { get; set; }
    }
    public class EmpModel
    {
        [Required]
        [DataType(DataType.Upload)]
        [Display(Name = "Select File")]
        public HttpPostedFileBase files { get; set; }
    }
    public class PdfDetails
    {
        public string policyNo { get; set; }
        public string telephone { get; set; }
        public string email { get; set; }
    }
}